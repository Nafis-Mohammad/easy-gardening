from django.apps import AppConfig


class PlantappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'plantapp'
